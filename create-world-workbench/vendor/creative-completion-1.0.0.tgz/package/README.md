# 创意补全独立包 1.0.0

输入一段文字，完成完整度判断、三个创意方向比较、自动扩写、语义审查和有限修订，输出统一 adaptationInput。支持独立 HTTP 服务及 TypeScript/JavaScript 模块调用。无需 Create World Agent 工作台或前端。

## 运行

需要 Node.js 24+。在解压目录执行（Windows 使用 npm.cmd，其他系统使用 npm）：

```powershell
npm.cmd ci
npm.cmd start
```

默认接口地址 http://127.0.0.1:4175/api/creative-completions/schema 。首次安装也可使用 npm.cmd install。ZIP 已含编译产物；修改源码后运行 npm.cmd run build。

模型固定 gpt-6-astra，沿用本机 Codex 账户登录。没有登录时执行 `npm.cmd run codex -- login`。账号须具备该模型权限，失败会明确返回，不替换模型。安装依赖需要网络；包不包含登录状态或额度。

端口通过 CREATIVE_COMPLETION_PORT 指定；数据位置通过 CREATIVE_COMPLETION_DATA_DIR 指定，默认在启动目录的 .data/creative-completion 内。环境变量需由调用方设置，.env.example 是示例，不会自动加载。服务仅监听本机。

## 作为模块接入

其他项目可执行 `npm install <本包目录>` 或安装同目录交付的 .tgz，然后：

```typescript
import { CreativeCompletionService, createCodexCompletionModel } from '@create-world/creative-completion';

const service = new CreativeCompletionService('./private-creative-data', createCodexCompletionModel());
try {
  const job = service.create({ source: '一个机器人寻找最后一朵花，结局温暖。' });
  await service.waitForIdle();
  const completed = service.get(job.id);
  if (completed.status === 'ready') {
    console.log(completed.result?.adaptationInput);
  } else {
    console.log(completed.status, completed.assessment?.questions, completed.error);
  }
} finally {
  await service.close();
}
```

`createCompletionApp(service)` 可用于单独挂载完整本机 HTTP 应用。输入、结果、任务和模型适配器类型随 dist/*.d.ts 提供。完整协议、错误码、状态机和预算见 [API.md](API.md)。

## 验证与文件

```powershell
npm.cmd run typecheck
npm.cmd test
npm.cmd run build
# 可选，真实模型调用，消耗账户额度
npm.cmd run smoke:codex
```

src 是独立源码，dist 是编译后的 ESM 与类型声明，tests 包含创意补全和 Codex 协议回归。SOURCE-FILES.json 记录上游文件与封装映射；MANIFEST.json 记录交付文件哈希；RELEASE-VERIFICATION.json 说明本次检查范围。

包只包含此模块，排除 node_modules、原项目、用户故事、运行证据、账号凭据、日志及参考材料。依赖许可证由各依赖包提供；本模块不额外授予开源许可，也未发布到 npm。

ready 仅表示创作稿可以交接，不表示生成了可玩游戏。运行验证与真人趣味性仍标为 not-tested / not-playtested。
