# 创意补全独立服务

把一段原创想法或未完成故事，判断并补全为可供游戏改编使用的创作稿。此目录是独立模块：**没有接入现有工作台、项目存储、改编管线或前端，也不会自动制作游戏。** Codex 调用适配器已封装为包内 `src/codex-harness.ts`；领域服务通过 `CompletionModel` 接口注入模型，便于单独迁移。

## 启动

在项目根目录运行：

```powershell
npm.cmd start
```

默认监听 `http://127.0.0.1:4175`，仅接受本机 Host / 同源请求，不提供静态文件或数据目录访问。模型固定为 `gpt-6-astra`，沿用项目内 Codex 登录；不会更换模型、修改全局配置或返回演示结果。POST 创建任务后才调用模型，会使用当前账户额度。

可选环境变量：

| 变量 | 默认值 | 用途 |
| --- | --- | --- |
| `CREATIVE_COMPLETION_PORT` | `4175` | 独立 API 端口 |
| `CREATIVE_COMPLETION_DATA_DIR` | `.data/creative-completion` | 私有持久化目录；相对启动命令的当前目录解析 |

同一服务一次运行一个任务，忙时返回 `409 busy`，不建立隐式队列。请勿同时启动多个进程操作同一个数据目录。当前是本机单用户服务，没有公网鉴权和多租户设计。

## API v1

所有 POST 请求使用 `Content-Type: application/json`；空参数动作传 `{}`。请求体最大 1 MiB。

| 方法 | 路径 | 返回 |
| --- | --- | --- |
| GET | `/api/creative-completions/schema` | 输入与模型阶段 JSON Schema、规则版本、预算 |
| POST | `/api/creative-completions` | `202`，创建并开始任务，返回任务快照和 `Location` |
| GET | `/api/creative-completions/:id` | `200`，状态、阶段、原始输入、判断、草稿、审查、调用次数和错误 |
| GET | `/api/creative-completions/:id/result` | 仅 `ready` 返回 `200 CompletionResult`，否则 `409 result_not_ready` |
| POST | `/api/creative-completions/:id/cancel` | 请求取消，返回任务快照；迟到的响应不会变成成功 |
| POST | `/api/creative-completions/:id/retry` | `202`，复用已验证检查点；仅允许 failed/cancelled/interrupted |

错误统一为 `{ "code": "...", "error": "..." }`；输入校验错误还含 `issues`。常见状态码：400 输入错误，403 非本机同源，404 不存在，409 忙/状态不允许/预算耗尽，413 请求过大，415 内容类型错误，500 内部错误。异步执行失败体现在任务 `status=failed` 与 `error`，创建请求的 202 不代表执行完成。

### 创建输入

最小请求：

```json
{
  "source": "一个机器人在废弃城市里寻找最后一朵花，结局温暖。"
}
```

完整请求示例：

```json
{
  "source": "一个机器人在废弃城市里寻找最后一朵花，结局温暖。",
  "direction": "轻量探索，重视发现与照料，不要战斗",
  "sourceKind": "original",
  "mustPreserve": ["机器人最终找到花", "结局温暖"],
  "clarifications": [],
  "capabilities": ["inspect", "dialogue", "activate", "choice", "inventory", "conditional-ending"],
  "scope": { "maxScenes": 3, "maxCharacters": 4, "maxBeats": 6 }
}
```

- `source`：必填，1–50,000 字符，不允许纯空白；保存原始文本，不裁剪内容。
- `direction`：可选，最多 2,000 字符。
- `sourceKind`：`auto`（默认，判断来源类型）、`original`（原创）、`adaptation`（已有作品改编）。显式来源类型不能被模型覆盖。
- `mustPreserve`：可选，最多 30 条必须保留的约束。模型也会从输入提取带逐字引文的约束。
- `clarifications`：可选，最多 10 组 `{question, answer}`。当结果为 `needs_input`，保留原始 source、附上问题回答，重新 POST 创建新任务。旧任务不可变更输入，保留审计依据。
- `capabilities`：可选，默认上表六种轻量交互。表示调用方声明允许的能力，并不代表本服务已经执行或验证对应运行时。
- `scope`：可选，默认 3 场景、4 角色、6 段。上限分别为 6、8、8；用于限制扩写稿，direct 分支保留原文，不擅自裁剪完整作品。

### 判断、进度与交接

任务状态：`running → ready | needs_input | failed | cancelled | interrupted`。阶段：`assessment → expansion → review → revision（必要时）→ review → done`。

判断路由：

| route | 行为 |
| --- | --- |
| `direct` | 完整文本直接返回，正文保持不变，不进行扩写与草稿复审 |
| `targeted` | 已有主干，仅补必要缺口 |
| `expand` | 稀疏原创种子，充分构思与展开 |
| `clarify` | 无法辨认创作意图、关键冲突、已有作品核心来源不足；最多 3 个必要问题，无交接结果 |

判断依照核心想法、玩家身份目标、冲突、因果、可玩行动和结局六个维度，不依据字数。普通原创空白直接补全。指定已有作品但材料不足时，不用模型记忆冒充原作。

需要扩写时，先生成三个不同方向并选择一个，产出完整正文、核心玩法、关键段落、结局、保留项与新增内容；随后用单独模型轮次审查意图、因果、行动、连贯性、能力适配和来源边界。审查失败最多修订一轮并复审，仍失败则不提供改编交接结果。

`ready` 的结果结构（精确 TypeScript 类型见 `contracts.ts`）：

```text
CompletionResult
  route                         direct | targeted | expand
  assessment                    六维判断、引用约束与创作空间
  draft                         扩写稿；direct 时为 null
    concepts / selectedConceptId / selectionReason
    title / hook / playerRole / coreLoop
    storyText / scenes / characters / beats / ending
    preserved / additions
  review                        六类审查与逐项约束核对；direct 时为 null
  adaptationInput
    sourceText / sourceOrigin / sourceSha256
    originalSource / originalSourceSha256
    constraints / direction / sourceKind / clarifications
    capabilities / scope / provenance
  verification
    structure                   passed
    modelReview                 passed | not-required
    runtime                     not-tested
    fun                         not-playtested
```

将 `result.adaptationInput` 作为之后改编流程的输入；需要详细玩法建议时同时消费 `result.draft`。同时消费 `constraints`、`direction` 和 `clarifications`，避免只取正文而丢掉用户补充的事实。`sourceOrigin=ai-expanded` 必须保留，新增内容是设计稿，不能改标为原作事实。`sourceSha256` 与段落引用应针对实际消费的 `sourceText`；用户原始输入单独通过 `originalSource` 保留。

主机检查 JSON、引用引文、约束覆盖、能力枚举、场景引用、数量上限及审查状态。模型审查是语义判断，不能证明运行可达或玩家觉得好玩。本模块不组装 HTML5、不调用游戏测试器，不把 `ready` 解释为游戏成品完成。

### PowerShell 调用

```powershell
$base = 'http://127.0.0.1:4175/api/creative-completions'
$body = @{ source = '一个机器人在废弃城市里寻找最后一朵花，结局温暖。' } | ConvertTo-Json
$job = Invoke-RestMethod -Method Post -Uri $base -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body))
Invoke-RestMethod -Uri "$base/$($job.id)"
# 仅在 status=ready 后取结果
Invoke-RestMethod -Uri "$base/$($job.id)/result"
# 取消或重试
Invoke-RestMethod -Method Post -Uri "$base/$($job.id)/cancel" -ContentType 'application/json' -Body '{}'
```

也可不启动 HTTP，直接导入 `index.ts`，实例化 `CreativeCompletionService(root, model)`，调用 `create/get/retry/cancel`。`CompletionModel.generate` 接收隔离工作目录、提示词、输出 Schema 和取消信号；测试可注入 fixture，生产适配器始终使用真实模型。

## 持久化与运行预算

```text
<data-root>/jobs/<job-id>.json                     主机任务记录
<data-root>/runs/<job-id>/<run-id>/                Agent 可读写工作区
<data-root>/artifacts/<job-id>/<run-id>/           主机证据与结果
```

原始输入、规则快照、所有模型响应（包括无效响应）、验证错误、草稿、审查和最终结果保存在私有目录，不通过静态服务器暴露。宿主写入拒绝符号链接/junction。模型不能写入宿主证据目录。

默认每个任务累计最多 10 次模型调用、15 分钟运行时间、3 次运行尝试；每任务最多 2 次合同修复、1 次创作修订。正常直通 1 次调用，正常补全 3 次，补全加一轮修订 5 次。预算包含失败调用和手动重试。模型传输/认证故障直接失败，不自动换模型或当作内容错误无限修复。

重试复用已经校验的判断和草稿，继续缺失阶段。服务重启将运行中的任务标记为 interrupted。修改规则或 Schema 后旧检查点不能继续，需用原始输入创建新任务。澄清通过新任务处理。新任务、新尝试与旧证据分别保存。

## 验证

自动回归（注入模型，验证合同与控制流，不代表真实创作质量）：

```powershell
npm.cmd test
npm.cmd run typecheck
npm.cmd test
npm.cmd run build
```

真实模型接口试运行（显式消耗账户额度，使用独立私有目录，最多 6 次调用/5 分钟）：

```powershell
npm.cmd run smoke:codex
```

该脚本通过临时本机 HTTP 端口创建一个机器人找花的原创样本、轮询状态并读取 result 接口，证据保存在 `.data/creative-completion-smoke/<时间>/`。结果是该样本的接口与模型链路证据，不是任意输入成功率或真人趣味性结论。
