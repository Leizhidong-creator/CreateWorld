(function () {
"use strict";
let __bwmMountOptions = null;
const __bwmRuntime = window.BeyondWallsReactRuntime;
if (!__bwmRuntime) throw new Error("Load shared/react-runtime.js before 地下水管迷宫/source.js");
const _ = __bwmRuntime.React;
const v = __bwmRuntime.ReactDOM;
const T = __bwmRuntime.jsxRuntime;
var y = Object.freeze({
	up: Object.freeze({
		name: "up",
		bit: 1,
		opposite: 4,
		dx: 0,
		dy: -1
	}),
	right: Object.freeze({
		name: "right",
		bit: 2,
		opposite: 8,
		dx: 1,
		dy: 0
	}),
	down: Object.freeze({
		name: "down",
		bit: 4,
		opposite: 1,
		dx: 0,
		dy: 1
	}),
	left: Object.freeze({
		name: "left",
		bit: 8,
		opposite: 2,
		dx: -1,
		dy: 0
	})
}), b = Object.values(y);
function x(e) {
	let t = String(e), n = 2166136261;
	for (let e = 0; e < t.length; e += 1) n ^= t.charCodeAt(e), n = Math.imul(n, 16777619);
	return n >>> 0;
}
function ee(e) {
	let t = x(e) || 2654435769;
	return () => {
		t += 1831565813;
		let e = t;
		return e = Math.imul(e ^ e >>> 15, e | 1), e ^= e + Math.imul(e ^ e >>> 7, e | 61), ((e ^ e >>> 14) >>> 0) / 4294967296;
	};
}
function S(e, t, n) {
	return t * n + e;
}
function C(e, t, n, r) {
	return e >= 0 && t >= 0 && e < n && t < r;
}
function te(e, t, n) {
	let r = ee(e), i = Array(t * n).fill(0), a = new Set([S(0, 0, t)]), o = [{
		x: 0,
		y: 0
	}];
	for (; o.length > 0;) {
		let e = o[o.length - 1], s = b.filter((r) => {
			let i = e.x + r.dx, o = e.y + r.dy;
			return C(i, o, t, n) && !a.has(S(i, o, t));
		});
		if (s.length === 0) {
			o.pop();
			continue;
		}
		let c = s[Math.floor(r() * s.length)], l = {
			x: e.x + c.dx,
			y: e.y + c.dy
		}, u = S(e.x, e.y, t), d = S(l.x, l.y, t);
		i[u] |= c.bit, i[d] |= c.opposite, a.add(d), o.push(l);
	}
	return i;
}
function ne(e, t, n) {
	let r = S(0, 0, t), i = [{
		x: 0,
		y: 0
	}], a = new Map([[r, 0]]), o = /* @__PURE__ */ new Map();
	for (let n = 0; n < i.length; n += 1) {
		let r = i[n], s = S(r.x, r.y, t);
		for (let n of b) {
			if ((e[s] & n.bit) === 0) continue;
			let c = {
				x: r.x + n.dx,
				y: r.y + n.dy
			}, l = S(c.x, c.y, t);
			a.has(l) || (a.set(l, a.get(s) + 1), o.set(l, s), i.push(c));
		}
	}
	return {
		distance: a,
		parent: o
	};
}
function re(e, t, n) {
	let r = [], i = S(t.x, t.y, n);
	for (; i !== void 0 && (r.push({
		x: i % n,
		y: Math.floor(i / n)
	}), i !== 0);) i = e.get(i);
	return r.reverse();
}
function w(e, t, n) {
	let { distance: r, parent: i } = ne(e, t, n), a = [];
	for (let e = 0; e < n; e += 1) for (let i = 0; i < t; i += 1) {
		if (i !== t - 1 && e !== n - 1 || i === 0 && e === 0) continue;
		let o = r.get(S(i, e, t)), s = i === t - 1 ? "right" : "down";
		a.push({
			x: i,
			y: e,
			steps: o,
			exitDirection: s,
			penalty: o < 9 ? 9 - o : o > 16 ? o - 16 : 0
		});
	}
	a.sort((e, t) => e.penalty - t.penalty || Math.abs(13 - e.steps) - Math.abs(13 - t.steps));
	let o = a[0];
	return {
		exit: {
			x: o.x,
			y: o.y
		},
		exitDirection: o.exitDirection,
		solution: re(i, o, t),
		solutionSteps: o.steps + 1,
		penalty: o.penalty
	};
}
function ie(e, t = 6, n = 7) {
	let r = null;
	for (let i = 0; i < 160; i += 1) {
		let a = te(`${e}:${i}`, t, n), o = w(a, t, n), s = {
			seed: String(e),
			generation: i,
			columns: t,
			rows: n,
			cells: a,
			start: {
				x: 0,
				y: 0
			},
			...o
		};
		if ((!r || s.penalty < r.penalty || s.penalty === r.penalty && Math.abs(14 - s.solutionSteps) < Math.abs(14 - r.solutionSteps)) && (r = s), s.penalty === 0 && s.solutionSteps >= 11) return s;
	}
	return r;
}
function ae(e, t) {
	return C(t.x, t.y, e.columns, e.rows) ? e.cells[S(t.x, t.y, e.columns)] : 0;
}
function oe(e, t, n) {
	let r = y[n];
	return r ? t.x === e.exit.x && t.y === e.exit.y && n === e.exitDirection ? {
		position: {
			x: t.x + r.dx,
			y: t.y + r.dy
		},
		moved: !0,
		exited: !0
	} : (ae(e, t) & r.bit) === 0 ? {
		position: { ...t },
		moved: !1,
		exited: !1
	} : {
		position: {
			x: t.x + r.dx,
			y: t.y + r.dy
		},
		moved: !0,
		exited: !1
	} : {
		position: { ...t },
		moved: !1,
		exited: !1
	};
}
var ce = "1.0.0", le = 48, E = 18, D = 6 * le + E * 2, ue = 7 * le + E * 2, de = "underground-pipe-blueprint", fe = "地下水管图纸", pe = 82, O = le * .56;
function k() {
	if (typeof window > "u") return {
		seed: Date.now(),
		embedded: !1,
		nextDestination: null
	};
	let e = new URLSearchParams(window.location.search), t = __bwmMountOptions || {};
	return {
		seed: t.seed || e.get("seed") || Date.now(),
		embedded: typeof t.embedded === "boolean" ? t.embedded : e.get("embed") === "1",
		nextDestination: t.nextDestination || e.get("next")
	};
}
function he(e, t) {
	let n = {
		source: "pipe-maze",
		version: ce,
		type: e,
		detail: t
	};
	if (__bwmMountOptions && typeof __bwmMountOptions.onEvent === "function") __bwmMountOptions.onEvent(n);
	window.dispatchEvent(new CustomEvent(e.toLowerCase(), { detail: t }));
}
function ge({ name: e }) {
	return /* @__PURE__ */ (0, T.jsx)("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, T.jsx)("path", { d: {
			undo: "M4 7h10a5 5 0 0 1 0 10h-2v-2h2a3 3 0 1 0 0-6H4l3 3-1.4 1.4L.2 8l5.4-5.4L7 4z",
			sound: "M3 9v6h4l5 4V5L7 9H3zm12.5 3a4 4 0 0 0-2-3.46v6.92A4 4 0 0 0 15.5 12zm0-7v2.06a6 6 0 0 1 0 9.88V19a8 8 0 0 0 0-14z",
			mute: "M3 9v6h4l5 4V5L7 9H3zm11.7.3-1.4 1.4 1.3 1.3-1.3 1.3 1.4 1.4 1.3-1.3 1.3 1.3 1.4-1.4-1.3-1.3 1.3-1.3-1.4-1.4-1.3 1.3z"
		}[e] })
	});
}
function _e(e) {
	return {
		x: E + e.x * le + le / 2,
		y: E + e.y * le + le / 2
	};
}
function ve(e, t, n, r, i) {
	e.beginPath(), e.moveTo(Math.round(t), Math.round(n)), e.lineTo(Math.round(r), Math.round(i)), e.lineCap = "square", e.lineWidth = 28, e.strokeStyle = "#080706", e.stroke(), e.lineWidth = 23, e.strokeStyle = "#292925", e.stroke(), e.lineWidth = 17, e.strokeStyle = "#686451", e.stroke(), e.lineWidth = 12, e.strokeStyle = "#3f402f", e.stroke(), e.setLineDash([5, 7]), e.lineDashOffset = 2, e.lineWidth = 2, e.strokeStyle = "rgba(151, 145, 98, 0.34)", e.stroke(), e.setLineDash([]);
}
function ye(e, t, n) {
	e.fillStyle = "#080706", e.fillRect(t.x - 15, t.y - 15, 30, 30), e.fillStyle = "#292925", e.fillRect(t.x - 12, t.y - 12, 24, 24), e.fillStyle = "#66614e", e.fillRect(t.x - 9, t.y - 9, 18, 18), e.fillStyle = "#3f402f", e.fillRect(t.x - 6, t.y - 6, 12, 12), (n & y.up.bit) !== 0 && e.fillRect(t.x - 6, t.y - 15, 12, 15), (n & y.right.bit) !== 0 && e.fillRect(t.x, t.y - 6, 15, 12), (n & y.down.bit) !== 0 && e.fillRect(t.x - 6, t.y, 12, 15), (n & y.left.bit) !== 0 && e.fillRect(t.x - 15, t.y - 6, 15, 12), e.fillStyle = "#a49a72", e.fillRect(t.x - 11, t.y - 11, 2, 2), e.fillRect(t.x + 9, t.y + 9, 2, 2);
}
function be(e, t, n, r, i) {
	e.clearRect(0, 0, D, ue), e.imageSmoothingEnabled = !1, e.fillStyle = "#0a0706", e.fillRect(0, 0, D, ue);
	for (let n = 0; n < 190; n += 1) {
		let r = (n * 61 + t.generation * 7) % D, i = (n * 43 + t.generation * 11) % ue, a = n % 7 == 0 ? 3 : 2;
		e.fillStyle = n % 4 == 0 ? "#2d1d13" : "#1b120d", e.fillRect(r, i, a, a);
	}
	for (let n = 0; n < t.rows; n += 1) for (let r = 0; r < t.columns; r += 1) {
		let i = ae(t, {
			x: r,
			y: n
		}), a = _e({
			x: r,
			y: n
		});
		if ((i & y.right.bit) !== 0) {
			let t = _e({
				x: r + 1,
				y: n
			});
			ve(e, a.x, a.y, t.x, t.y);
		}
		if ((i & y.down.bit) !== 0) {
			let t = _e({
				x: r,
				y: n + 1
			});
			ve(e, a.x, a.y, t.x, t.y);
		}
	}
	let a = _e(t.exit), o = y[t.exitDirection];
	ve(e, a.x, a.y, a.x + o.dx * 36, a.y + o.dy * 36);
	for (let n = 0; n < t.rows; n += 1) for (let r = 0; r < t.columns; r += 1) ye(e, _e({
		x: r,
		y: n
	}), ae(t, {
		x: r,
		y: n
	}));
	r.length > 1 && (e.beginPath(), r.forEach((t, n) => {
		let r = _e(t);
		n === 0 ? e.moveTo(r.x, r.y) : e.lineTo(r.x, r.y);
	}), e.lineJoin = "bevel", e.lineCap = "square", e.lineWidth = 9, e.strokeStyle = "rgba(19, 11, 7, 0.76)", e.stroke(), e.lineWidth = 5, e.strokeStyle = "#c27a2b", e.stroke(), e.setLineDash([2, 5]), e.lineWidth = 1, e.strokeStyle = "#ffe093", e.stroke(), e.setLineDash([]));
	let s = _e(t.start);
	e.fillStyle = "#172015", e.fillRect(s.x - 7, s.y - 7, 14, 14), e.fillStyle = "#6c8e54", e.fillRect(s.x - 4, s.y - 4, 8, 8), e.fillStyle = "#c5d48c", e.fillRect(s.x - 2, s.y - 2, 4, 4);
	let c = a.x + o.dx * 20, l = a.y + o.dy * 20;
	if (e.fillStyle = "rgba(214, 142, 49, 0.22)", e.fillRect(c - 9, l - 9, 18, 18), e.fillStyle = "#d99032", e.fillRect(c - 5, l - 5, 10, 10), e.fillStyle = "#ffe08a", e.fillRect(c - 2, l - 2, 4, 4), i !== "complete" && i !== "timeout") {
		let t = _e(n);
		e.fillStyle = "rgba(238, 165, 50, 0.2)", e.fillRect(t.x - 12, t.y - 12, 24, 24), e.fillStyle = "#0e0b08", e.fillRect(t.x - 8, t.y - 8, 16, 16), e.fillStyle = "#b66724", e.fillRect(t.x - 6, t.y - 6, 12, 12), e.fillStyle = "#ffd168", e.fillRect(t.x - 3, t.y - 3, 6, 6);
	}
}
function xe(e, t, n) {
	return {
		x: n.x + (e.x + .5) * (n.width / t.columns),
		y: n.y + (e.y + .5) * (n.height / t.rows)
	};
}
function Se(e, t) {
	let n = document.createElement("canvas");
	n.width = 128, n.height = 128;
	let r = n.getContext("2d");
	r.imageSmoothingEnabled = !1;
	let i = [
		[18, 22],
		[22, 13],
		[34, 11],
		[47, 15],
		[51, 12],
		[68, 16],
		[73, 12],
		[91, 17],
		[99, 16],
		[113, 27],
		[111, 40],
		[116, 47],
		[112, 62],
		[117, 70],
		[112, 86],
		[114, 96],
		[102, 111],
		[88, 109],
		[81, 115],
		[65, 111],
		[57, 117],
		[42, 111],
		[32, 114],
		[15, 104],
		[17, 91],
		[11, 83],
		[16, 67],
		[11, 58],
		[17, 42],
		[13, 34]
	];
	function a(e = 0, t = 0) {
		let n = new Path2D();
		return i.forEach(([r, i], a) => {
			a === 0 ? n.moveTo(r + e, i + t) : n.lineTo(r + e, i + t);
		}), n.closePath(), n;
	}
	let o = a();
	r.fillStyle = "#3d210d", r.fill(a(4, 5)), r.fillStyle = "#704018", r.fill(a(2, 2)), r.fillStyle = "#d59a45", r.fill(o), r.lineJoin = "miter", r.lineWidth = 3, r.strokeStyle = "#87521f", r.stroke(o), r.lineWidth = 1, r.strokeStyle = "#f0c36d", r.stroke(o);
	let s = (e.generation + 1) * 2654435761 + t.length * 1013904223 >>> 0;
	function c() {
		return s = s * 1664525 + 1013904223 >>> 0, s / 4294967296;
	}
	r.save(), r.clip(o), r.fillStyle = "#e3ad59", r.fillRect(23, 22, 83, 80);
	for (let e = 0; e < 230; e += 1) {
		let e = Math.floor(11 + c() * 106), t = Math.floor(11 + c() * 106), n = c() < .13 ? 4 : c() < .42 ? 2 : 1;
		r.fillStyle = [
			"rgba(91, 50, 18, .14)",
			"rgba(126, 72, 25, .11)",
			"rgba(255, 217, 133, .13)",
			"rgba(235, 180, 83, .18)"
		][Math.floor(c() * 4)], r.fillRect(e, t, n, n);
	}
	r.fillStyle = "rgba(91, 48, 16, .18)", [
		[
			18,
			30,
			10,
			5
		],
		[
			20,
			34,
			6,
			9
		],
		[
			92,
			22,
			12,
			5
		],
		[
			103,
			30,
			6,
			11
		],
		[
			14,
			77,
			10,
			10
		],
		[
			96,
			93,
			12,
			12
		],
		[
			45,
			106,
			9,
			5
		]
	].forEach(([e, t, n, i]) => {
		r.fillRect(e, t, n, i), r.fillRect(e + 2, t - 2, Math.max(2, n - 4), 2);
	}), r.fillStyle = "rgba(111, 65, 23, .12)", r.fillRect(26, 26, 2, 75), r.fillRect(27, 25, 66, 1), r.fillRect(100, 35, 1, 61), r.restore();
	let l = {
		x: 31,
		y: 30,
		width: 66,
		height: 70
	};
	l.width / e.columns, l.height / e.rows, r.lineCap = "square", r.lineJoin = "miter", r.beginPath();
	for (let t = 0; t < e.rows; t += 1) for (let n = 0; n < e.columns; n += 1) {
		let i = ae(e, {
			x: n,
			y: t
		}), a = xe({
			x: n,
			y: t
		}, e, l);
		if ((i & y.right.bit) !== 0) {
			let i = xe({
				x: n + 1,
				y: t
			}, e, l);
			r.moveTo(Math.round(a.x), Math.round(a.y)), r.lineTo(Math.round(i.x), Math.round(i.y));
		}
		if ((i & y.down.bit) !== 0) {
			let i = xe({
				x: n,
				y: t + 1
			}, e, l);
			r.moveTo(Math.round(a.x), Math.round(a.y)), r.lineTo(Math.round(i.x), Math.round(i.y));
		}
	}
	r.globalAlpha = .42, r.lineWidth = 1, r.strokeStyle = "#765022", r.stroke(), r.globalAlpha = 1, r.beginPath(), t.forEach((t, n) => {
		let i = xe(t, e, l), a = Math.round(i.x), o = Math.round(i.y);
		n === 0 ? r.moveTo(a, o) : r.lineTo(a, o);
	}), r.lineWidth = 5, r.strokeStyle = "rgba(96, 50, 17, .2)", r.stroke(), r.lineWidth = 3, r.strokeStyle = "#68441d", r.stroke(), r.setLineDash([1, 3]), r.lineWidth = 1, r.strokeStyle = "#a87534", r.stroke(), r.setLineDash([]);
	let u = xe(e.start, e, l), d = Math.round(u.x), f = Math.round(u.y);
	r.strokeStyle = "#65421d", r.lineWidth = 2, r.strokeRect(d - 5, f - 5, 10, 10), r.beginPath(), r.moveTo(d - 2, f + 2), r.lineTo(d - 2, f - 2), r.lineTo(d + 2, f - 2), r.lineTo(d + 2, f + 1), r.lineTo(d, f + 1), r.stroke();
	let p = xe(t[t.length - 1], e, l), m = Math.round(p.x), h = Math.round(p.y);
	r.lineWidth = 3, r.strokeStyle = "#5b3818", r.beginPath(), r.moveTo(m - 4, h - 4), r.lineTo(m + 4, h + 4), r.moveTo(m + 4, h - 4), r.lineTo(m - 4, h + 4), r.stroke(), r.fillStyle = "#755022", r.fillRect(42, 20, 2, 4), r.fillRect(67, 22, 1, 5), r.fillRect(105, 54, 3, 3), r.fillRect(21, 63, 2, 5), r.fillRect(75, 107, 2, 2), r.fillRect(80, 107, 2, 2);
	let g = document.createElement("canvas");
	g.width = 512, g.height = 512;
	let _ = g.getContext("2d");
	return _.imageSmoothingEnabled = !1, _.drawImage(n, 0, 0, n.width, n.height, 0, 0, g.width, g.height), g.toDataURL("image/png");
}
function Ce({ status: e, onStart: t }) {
	return e === "ready" ? /* @__PURE__ */ (0, T.jsx)("div", {
		className: "pipe-intro",
		role: "button",
		tabIndex: 0,
		"aria-label": "点击开始地下水管迷宫",
		onPointerDown: (e) => {
			e.button !== void 0 && e.button !== 0 || (e.preventDefault(), t());
		},
		children: /* @__PURE__ */ (0, T.jsxs)("div", {
			className: "pipe-intro__message",
			children: [/* @__PURE__ */ (0, T.jsx)("p", { children: "在25秒内按住屏幕，沿地下水管持续拖动到出口；通关路线会保存为图纸。" }), /* @__PURE__ */ (0, T.jsx)("span", { children: "点击空白处开始" })]
		})
	}) : null;
}
function we({ status: e, onRetry: t }) {
	return e === "timeout" ? /* @__PURE__ */ (0, T.jsx)("div", {
		className: "pipe-timeout",
		role: "button",
		tabIndex: 0,
		"aria-label": "时间到，点击重新尝试",
		onPointerDown: (e) => {
			e.button !== void 0 && e.button !== 0 || (e.preventDefault(), t());
		},
		children: /* @__PURE__ */ (0, T.jsxs)("div", {
			className: "pipe-timeout__message",
			children: [/* @__PURE__ */ (0, T.jsx)("p", { children: "时间到" }), /* @__PURE__ */ (0, T.jsx)("span", { children: "点击空白处重新尝试" })]
		})
	}) : null;
}
function Te({ open: e, onConfirm: t, onCancel: n }) {
	return e ? /* @__PURE__ */ (0, T.jsx)("div", {
		className: "pipe-confirm-shade",
		role: "dialog",
		"aria-modal": "true",
		"aria-labelledby": "pipe-confirm-title",
		children: /* @__PURE__ */ (0, T.jsxs)("div", {
			className: "pipe-confirm-card",
			children: [
				/* @__PURE__ */ (0, T.jsx)("p", {
					className: "pipe-confirm-card__eyebrow",
					children: "重置路线"
				}),
				/* @__PURE__ */ (0, T.jsx)("h2", {
					id: "pipe-confirm-title",
					children: "是否重新开始？"
				}),
				/* @__PURE__ */ (0, T.jsx)("p", { children: "地图内容不会改变，确认后将回到起点并重新计时。" }),
				/* @__PURE__ */ (0, T.jsxs)("div", {
					className: "pipe-confirm-card__actions",
					children: [/* @__PURE__ */ (0, T.jsx)("button", {
						type: "button",
						onClick: t,
						children: "是"
					}), /* @__PURE__ */ (0, T.jsx)("button", {
						type: "button",
						onClick: n,
						children: "取消"
					})]
				})
			]
		})
	}) : null;
}
function Ee({ status: e, blueprint: t }) {
	return e !== "complete" || !t ? null : /* @__PURE__ */ (0, T.jsx)("div", {
		className: "pipe-result-shade",
		role: "status",
		"aria-live": "assertive",
		children: /* @__PURE__ */ (0, T.jsxs)("div", {
			className: "pipe-result-card",
			children: [
				/* @__PURE__ */ (0, T.jsx)("p", {
					className: "pipe-result-card__eyebrow",
					children: "路线已经绘制"
				}),
				/* @__PURE__ */ (0, T.jsx)("h2", { children: "成功走出迷宫" }),
				/* @__PURE__ */ (0, T.jsx)("div", {
					className: "pipe-blueprint",
					children: /* @__PURE__ */ (0, T.jsx)("img", {
						src: t,
						alt: "记录实际通关路线的地下水管图纸"
					})
				}),
				/* @__PURE__ */ (0, T.jsxs)("div", {
					className: "pipe-item-acquired",
					children: [/* @__PURE__ */ (0, T.jsx)("span", {
						"aria-hidden": "true",
						children: "▰"
					}), /* @__PURE__ */ (0, T.jsxs)("div", { children: [/* @__PURE__ */ (0, T.jsx)("small", { children: "获得道具" }), /* @__PURE__ */ (0, T.jsx)("strong", { children: fe })] })]
				}),
				/* @__PURE__ */ (0, T.jsx)("p", {
					className: "pipe-result-card__continuing",
					children: "图纸已保存 · 正在进入下一部分…"
				})
			]
		})
	});
}
function De() {
	let e = (0, _.useMemo)(k, []), t = (0, _.useRef)(null), n = (0, _.useRef)(ie(e.seed)), r = (0, _.useRef)({ ...n.current.start }), i = (0, _.useRef)([{ ...n.current.start }]), a = (0, _.useRef)("ready"), o = (0, _.useRef)(!0), s = (0, _.useRef)(!1), c = (0, _.useRef)(25), l = (0, _.useRef)(null), u = (0, _.useRef)(!1), d = (0, _.useRef)(25), f = (0, _.useRef)(null), p = (0, _.useRef)(null), m = (0, _.useRef)(e.nextDestination), h = (0, _.useRef)(null), g = (0, _.useRef)(null), v = (0, _.useRef)(() => {}), y = (0, _.useRef)(() => {}), b = (0, _.useRef)(() => {}), x = (0, _.useRef)(() => {}), ee = (0, _.useRef)(() => {}), S = (0, _.useRef)(() => {}), [C, te] = (0, _.useState)("ready"), [ne, re] = (0, _.useState)(25), [w, ae] = (0, _.useState)(0), [se, le] = (0, _.useState)(null), [E, ve] = (0, _.useState)(!1), [ye, xe] = (0, _.useState)(!1), [De, Oe] = (0, _.useState)(!0), [ke, Ae] = (0, _.useState)("请阅读玩法说明，点击空白处开始。"), A = (0, _.useCallback)(() => {
		let e = n.current;
		return {
			seed: e.seed,
			generation: e.generation,
			status: a.current,
			solved: a.current === "complete",
			enabled: o.current,
			muted: s.current,
			timeLimit: 25,
			timeLeft: c.current,
			controlMode: "continuous-drag",
			resetConfirmationOpen: u.current,
			moveCount: i.current.length - 1,
			position: { ...r.current },
			start: { ...e.start },
			exit: { ...e.exit },
			exitDirection: e.exitDirection,
			minimumMoves: e.solutionSteps,
			route: i.current.map((e) => ({ ...e })),
			blueprintAvailable: !!p.current,
			item: a.current === "complete" ? {
				id: de,
				name: fe
			} : null
		};
	}, []), je = (0, _.useCallback)((e, t = .08) => {
		if (!(s.current || typeof window > "u")) try {
			let n = window.AudioContext || window.webkitAudioContext;
			if (!n) return;
			g.current || (g.current = new n());
			let r = g.current, i = r.createOscillator(), a = r.createGain();
			i.type = "square", i.frequency.setValueAtTime(e, r.currentTime), a.gain.setValueAtTime(.035, r.currentTime), a.gain.exponentialRampToValueAtTime(1e-4, r.currentTime + t), i.connect(a), a.connect(r.destination), i.start(), i.stop(r.currentTime + t);
		} catch {}
	}, []), Me = (0, _.useCallback)((e) => {
		let t = !!e;
		o.current = t, Oe(t);
	}, []), Ne = (0, _.useCallback)((e) => {
		let t = !!e;
		s.current = t, xe(t);
	}, []), Pe = (0, _.useCallback)(() => {
		!o.current || a.current !== "ready" || (a.current = "playing", l.current = performance.now(), c.current = 25, re(25), te("playing"), Ae("计时开始，请按住屏幕沿管道持续拖动。"), je(440, .1), he("PIPE_MAZE_START", A()));
	}, [A, je]);
	v.current = Pe;
	let Fe = (0, _.useCallback)(() => {
		a.current === "playing" && (a.current = "timeout", f.current = null, c.current = 0, re(0), te("timeout"), Ae("时间到，请重新尝试。"), je(150, .22), he("PIPE_MAZE_TIMEOUT", A()));
	}, [A, je]);
	S.current = Fe;
	let Ie = (0, _.useCallback)(() => {
		if (a.current !== "playing" || u.current) return;
		let e = l.current === null ? 0 : (performance.now() - l.current) / 1e3, t = Math.max(0, 25 - e);
		if (t <= 0) {
			Fe();
			return;
		}
		d.current = t, c.current = t, re(Math.ceil(t)), u.current = !0, f.current = null, ve(!0), Ae("互动内容已暂停，请确认是否重新开始。"), he("PIPE_MAZE_RESTART_CONFIRM", A());
	}, [A, Fe]), Le = (0, _.useCallback)(() => {
		if (!u.current) return;
		let e = d.current;
		l.current = performance.now() - (25 - e) * 1e3, c.current = e, u.current = !1, ve(!1), re(Math.ceil(e)), Ae("已取消重置，继续计时并保留当前路线。"), he("PIPE_MAZE_RESTART_CANCELLED", A());
	}, [A]), Re = (0, _.useCallback)(() => {
		h.current && (window.clearTimeout(h.current), h.current = null), r.current = { ...n.current.start }, i.current = [{ ...n.current.start }], p.current = null, l.current = performance.now(), c.current = 25, d.current = 25, u.current = !1, a.current = "playing", te("playing"), ve(!1), re(25), ae(0), le(null), Ae("已回到起点，地图保持不变，重新开始计时。"), je(390, .1), queueMicrotask(() => he("PIPE_MAZE_RESTART", A()));
	}, [A, je]);
	ee.current = Re;
	let ze = (0, _.useCallback)(() => {
		if (a.current !== "playing") return;
		a.current = "complete", te("complete");
		let e = Se(n.current, i.current);
		p.current = e, le(e);
		try {
			window.localStorage.setItem("pipe-maze-blueprint", e);
		} catch {}
		let t = {
			id: de,
			name: fe,
			type: "quest-item",
			blueprint: e
		}, r = {
			...A(),
			item: t,
			blueprint: e
		};
		Ae(`成功走出迷宫，获得道具：${fe}。`), je(760, .2), he("PIPE_MAZE_ITEM_ACQUIRED", t), he("PIPE_MAZE_COMPLETE", r);
	}, [A, je]), Be = (0, _.useCallback)((e) => {
		if (!o.current || a.current !== "playing" || u.current) return !1;
		if (l.current !== null && performance.now() - l.current >= 25 * 1e3) return Fe(), !1;
		let t = oe(n.current, r.current, e);
		return t.moved ? (r.current = t.position, i.current = [...i.current, { ...t.position }], ae(i.current.length - 1), Ae(t.exited ? "已经找到出口。" : `向${{
			up: "上",
			right: "右",
			down: "下",
			left: "左"
		}[e]}移动。`), je(t.exited ? 660 : 330, t.exited ? .14 : .055), he("PIPE_MAZE_MOVE", {
			direction: e,
			moved: !0,
			exited: t.exited,
			state: A()
		}), t.exited && ze(), !0) : (je(170, .05), Ae("这个方向被管壁挡住了。"), he("PIPE_MAZE_BLOCKED", {
			direction: e,
			state: A()
		}), !1);
	}, [
		ze,
		A,
		Fe,
		je
	]);
	y.current = Be, b.current = (0, _.useCallback)((e) => {
		let i = f.current;
		if (!i || !o.current || a.current !== "playing" || u.current || e < i.nextMoveAt) return;
		let s = t.current;
		if (!s) return;
		let c = s.getBoundingClientRect();
		if (c.width <= 0 || c.height <= 0) return;
		let l = (i.x - c.left) / c.width * D, d = (i.y - c.top) / c.height * ue, p = l - i.offsetX, m = d - i.offsetY, h = _e(r.current), g = p - h.x, _ = m - h.y, v = g >= 0 ? "right" : "left", b = _ >= 0 ? "down" : "up", x = (Math.abs(g) >= Math.abs(_) ? [{
			direction: v,
			distance: Math.abs(g)
		}, {
			direction: b,
			distance: Math.abs(_)
		}] : [{
			direction: b,
			distance: Math.abs(_)
		}, {
			direction: v,
			distance: Math.abs(g)
		}]).find(({ direction: e, distance: t }) => t < O ? !1 : oe(n.current, r.current, e).moved)?.direction;
		if (!x) {
			i.nextMoveAt = e + pe;
			return;
		}
		i.nextMoveAt = e + pe, y.current(x);
	}, []);
	let Ve = (0, _.useCallback)((e = {}) => {
		h.current && (window.clearTimeout(h.current), h.current = null);
		let t = ie(e.seed ?? Date.now());
		n.current = t, r.current = { ...t.start }, i.current = [{ ...t.start }], f.current = null, p.current = null, l.current = null, c.current = 25, d.current = 25, u.current = !1;
		let o = e.start === !0 ? "playing" : "ready";
		a.current = o, o === "playing" && (l.current = performance.now()), te(o), re(25), ae(0), le(null), ve(!1), Ae(o === "playing" ? "迷宫已重新生成，计时开始。" : "请阅读玩法说明，点击空白处开始。"), queueMicrotask(() => he("PIPE_MAZE_RESET", A()));
	}, [A]);
	x.current = Ve, (0, _.useEffect)(() => {
		let e = t.current.getContext("2d"), s = 0, d = 25;
		function f(t) {
			if (a.current === "playing" && o.current && !u.current && l.current !== null) {
				let e = Math.max(0, 25 - (t - l.current) / 1e3);
				c.current = e;
				let n = Math.ceil(e);
				n !== d && (d = n, re(n)), e <= 0 && S.current();
			}
			be(e, n.current, r.current, i.current, a.current), b.current(t), s = window.requestAnimationFrame(f);
		}
		return s = window.requestAnimationFrame(f), () => window.cancelAnimationFrame(s);
	}, []), (0, _.useEffect)(() => {
		let e = {
			version: ce,
			start: () => v.current(),
			reset: (e) => x.current(e),
			restart: () => ee.current(),
			move: (e) => y.current(e),
			getState: () => A(),
			getBlueprint: () => p.current,
			downloadBlueprint: () => !1,
			setEnabled: Me,
			setMuted: Ne,
			setNextDestination: (e) => {
				m.current = e || null;
			}
		};
		window.PipeMazeGame = e;
		he("PIPE_MAZE_READY", e.getState());
		return () => {
			delete window.PipeMazeGame;
		};
	}, [
		A,
		Me,
		Ne
	]), (0, _.useEffect)(() => {
		function e(e) {
			let t = {
				w: "up",
				d: "right",
				s: "down",
				a: "left"
			};
			if (a.current === "ready" && (e.key === " " || e.key === "Enter")) {
				e.preventDefault(), Pe();
				return;
			}
			t[e.key.toLowerCase()] && (e.preventDefault(), Be(t[e.key.toLowerCase()])), e.key.toLowerCase() === "r" && Ie(), e.key.toLowerCase() === "m" && Ne(!s.current);
		}
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}, [
		Be,
		Ie,
		Ne,
		Pe
	]);
	let He = C === "playing" && ne <= 7;
	return /* @__PURE__ */ (0, T.jsxs)("main", {
		className: `pipe-game-shell ${e.embedded ? "is-embedded" : ""}`,
		children: [
			/* @__PURE__ */ (0, T.jsx)("div", { className: "pipe-ambient pipe-ambient--left" }),
			/* @__PURE__ */ (0, T.jsx)("div", { className: "pipe-ambient pipe-ambient--right" }),
			/* @__PURE__ */ (0, T.jsxs)("header", {
				className: "pipe-game-header",
				children: [
					/* @__PURE__ */ (0, T.jsx)("button", {
						type: "button",
						className: "pipe-icon-button",
						onClick: Ie,
						"aria-label": "重置路线，快捷键 R",
						title: "重置路线（R）",
						children: /* @__PURE__ */ (0, T.jsx)(ge, { name: "undo" })
					}),
					/* @__PURE__ */ (0, T.jsxs)("div", {
						className: "pipe-play-rule",
						children: [/* @__PURE__ */ (0, T.jsx)("h1", { children: "按住屏幕拖动前进" }), /* @__PURE__ */ (0, T.jsx)("p", { children: "让路线跟随手指，25秒内找到出口" })]
					}),
					/* @__PURE__ */ (0, T.jsx)("button", {
						type: "button",
						className: "pipe-icon-button",
						onClick: () => Ne(!ye),
						"aria-label": ye ? "开启音效，快捷键 M" : "关闭音效，快捷键 M",
						"aria-pressed": ye,
						title: "切换音效（M）",
						children: /* @__PURE__ */ (0, T.jsx)(ge, { name: ye ? "mute" : "sound" })
					})
				]
			}),
			/* @__PURE__ */ (0, T.jsxs)("div", {
				className: `pipe-timer ${He ? "is-danger" : ""}`,
				"aria-label": `剩余 ${ne} 秒`,
				children: [
					/* @__PURE__ */ (0, T.jsx)("span", { children: "剩余时间" }),
					/* @__PURE__ */ (0, T.jsx)("strong", { children: String(ne).padStart(2, "0") }),
					/* @__PURE__ */ (0, T.jsx)("i", { children: "秒" }),
					/* @__PURE__ */ (0, T.jsx)("div", {
						className: "pipe-timer__bar",
						"aria-hidden": "true",
						children: /* @__PURE__ */ (0, T.jsx)("em", { style: { width: `${Math.max(0, ne / 25 * 100)}%` } })
					})
				]
			}),
			/* @__PURE__ */ (0, T.jsx)("section", {
				className: `pipe-maze-stage ${De && C === "playing" ? "is-active" : ""}`,
				"data-testid": "pipe-maze-stage",
				onPointerDown: (e) => {
					if (e.button !== void 0 && e.button !== 0 || a.current !== "playing" || u.current || !o.current) return;
					let n = t.current;
					if (!n) return;
					let i = n.getBoundingClientRect(), s = (e.clientX - i.left) / i.width * D, c = (e.clientY - i.top) / i.height * ue, l = _e(r.current);
					f.current = {
						x: e.clientX,
						y: e.clientY,
						pointerId: e.pointerId,
						offsetX: s - l.x,
						offsetY: c - l.y,
						nextMoveAt: 0
					}, e.currentTarget.setPointerCapture?.(e.pointerId), e.preventDefault();
				},
				onPointerMove: (e) => {
					let t = f.current;
					!t || t.pointerId !== e.pointerId || (t.x = e.clientX, t.y = e.clientY, e.preventDefault());
				},
				onPointerUp: (e) => {
					let t = f.current;
					!t || t.pointerId !== e.pointerId || (f.current = null, e.currentTarget.releasePointerCapture?.(e.pointerId), e.preventDefault());
				},
				onPointerCancel: () => {
					f.current = null;
				},
				onLostPointerCapture: () => {
					f.current = null;
				},
				"aria-label": "地下水管迷宫区域，按住屏幕沿管道持续拖动",
				children: /* @__PURE__ */ (0, T.jsxs)("div", {
					className: "pipe-maze-frame",
					children: [
						/* @__PURE__ */ (0, T.jsx)("span", { className: "pipe-corner pipe-corner--one" }),
						/* @__PURE__ */ (0, T.jsx)("span", { className: "pipe-corner pipe-corner--two" }),
						/* @__PURE__ */ (0, T.jsx)("span", { className: "pipe-corner pipe-corner--three" }),
						/* @__PURE__ */ (0, T.jsx)("span", { className: "pipe-corner pipe-corner--four" }),
						/* @__PURE__ */ (0, T.jsx)("canvas", {
							ref: t,
							className: "pipe-maze-canvas",
							width: D,
							height: ue,
							role: "img",
							"aria-label": `地下水管迷宫，已移动 ${w} 步`
						})
					]
				})
			}),
			/* @__PURE__ */ (0, T.jsxs)("footer", {
				className: "pipe-game-footer",
				children: [
					/* @__PURE__ */ (0, T.jsx)("span", {}),
					/* @__PURE__ */ (0, T.jsx)("p", { children: "按住屏幕沿管道持续拖动 · 绘制离开路线" }),
					/* @__PURE__ */ (0, T.jsx)("span", {})
				]
			}),
			/* @__PURE__ */ (0, T.jsx)("div", {
				className: "pipe-sr-only",
				"aria-live": "polite",
				children: ke
			}),
			/* @__PURE__ */ (0, T.jsx)(Ce, {
				status: C,
				onStart: Pe
			}),
			/* @__PURE__ */ (0, T.jsx)(we, {
				status: C,
				onRetry: () => Ve({ start: !0 })
			}),
			/* @__PURE__ */ (0, T.jsx)(Te, {
				open: E,
				onConfirm: Re,
				onCancel: Le
			}),
			/* @__PURE__ */ (0, T.jsx)(Ee, {
				status: C,
				blueprint: se
			})
		]
	});
}

window.BeyondWallsMiniGameSources = window.BeyondWallsMiniGameSources || {};
window.BeyondWallsMiniGameSources.pipeMaze = {
  Component: De,
  setMountOptions(options) {
    __bwmMountOptions = Object.assign({ embedded: true }, options || {});
  },
  clearMountOptions() {
    __bwmMountOptions = null;
  },
  getApi() {
    return window.PipeMazeGame || null;
  }
};
})();
